========================================
  ARTIST'S 3D TOOLKIT - WEB VERSION
========================================

IMPORTANT: This app uses ES modules which browsers block
from file:// URLs for security reasons.

========================================
HOW TO RUN (Choose One):
========================================

OPTION 1: Use the Launcher (Easiest)
-------------------------------------
Windows: Double-click LAUNCH-APP.bat
Mac/Linux: Run ./LAUNCH-APP.sh

This starts a local server and opens http://localhost:3000


OPTION 2: Manual Server (If launcher fails)
-------------------------------------
1. Open terminal/command prompt in this folder
2. Run: python3 -m http.server 3000
   (or: python -m http.server 3000)
3. Open browser to: http://localhost:3000


OPTION 3: Use Node.js
-------------------------------------
1. Install Node.js from nodejs.org
2. Run: npx serve .
3. Open the URL it shows


OPTION 4: Direct File Access (May not work)
-------------------------------------
Some browsers (Chrome) block ES modules from file://.
Try:
- Firefox (best for local files)
- Edge with --allow-file-access-from-files flag  
- Chrome with web server (options above)


========================================
TROUBLESHOOTING:
========================================

❌ Blank page?
  → Browser blocked ES modules from file://
  → Use LAUNCH-APP script or run a server (see above)
  → Or try Firefox which is more permissive

❌ "Failed to load module"?
  → Same as above - need a web server

❌ Console shows CORS errors?
  → Must use http://localhost, not file://

========================================
FEATURES:
========================================

✓ 3D Forms (cube, sphere, cylinder, cone, pyramid)
✓ 6 Perspective Systems (1pt-5pt, fisheye)
✓ Human Anatomy (30+ landmarks, foreshortening)
✓ Animal Anatomy (horse, dog, cat, deer, lion)
✓ Composition Tools (golden ratio, rule of thirds)
✓ Measurement Tools

Total Size: 199KB
Works Offline: Yes (after first load)

========================================
