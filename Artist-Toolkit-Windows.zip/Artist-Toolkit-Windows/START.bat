@echo off
echo ==========================================
echo   ARTIST'S 3D TOOLKIT
echo ==========================================
echo.
echo Starting app on http://localhost:3000
echo.
echo Your browser will open automatically...
echo Press Ctrl+C to stop the server
echo ==========================================
echo.

REM Start server and open browser
start http://localhost:3000
python -m http.server 3000

pause
