@echo off
echo ==========================================
echo   ARTIST'S 3D TOOLKIT
echo ==========================================
echo.
echo Starting app with Node.js...
echo.

where node >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Node.js not found!
    echo Please use START.bat instead ^(uses Python^)
    echo Or install Node.js from https://nodejs.org/
    pause
    exit /b 1
)

start http://localhost:3000
npx -y serve -l 3000

pause
