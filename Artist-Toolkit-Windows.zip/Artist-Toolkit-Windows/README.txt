========================================
  ARTIST'S 3D TOOLKIT - WINDOWS
========================================

HOW TO RUN (Pick one):

OPTION 1: Double-click START.bat
  - Requires: Python (usually pre-installed)
  - Opens http://localhost:3000 automatically

OPTION 2: Double-click START-WITH-NODE.bat  
  - Requires: Node.js (download from nodejs.org)
  - Opens http://localhost:3000 automatically

OPTION 3: Manual
  - Open Command Prompt in this folder
  - Run: python -m http.server 3000
  - Open browser to http://localhost:3000

========================================
FEATURES:
========================================

✓ 3D Forms (cube, sphere, cylinder, cone, pyramid)
✓ 6 Perspective Systems (1pt-5pt, fisheye)
✓ Human Anatomy (30+ landmarks, foreshortening)
✓ Animal Anatomy (5 quadruped types)
✓ Composition Tools (golden ratio, rule of thirds)
✓ Measurements & Analysis

Total Size: 199KB
Works Offline: Yes

========================================
TROUBLESHOOTING:
========================================

❌ "Python not found"?
  → Install Python from python.org
  → Or use START-WITH-NODE.bat

❌ Port 3000 already in use?
  → Close other apps using port 3000
  → Or edit START.bat and change 3000 to 8000

❌ Browser doesn't open?
  → Manually go to http://localhost:3000

========================================
